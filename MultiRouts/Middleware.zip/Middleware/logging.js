const express=require("express")
const app=express()
app.use((req,res,next)=>{
    const date=new Date().toISOString()
    const method=req.method
    const url=req.url
    console.log(`${date} ${method} ${url}`)
    next();
})
module.exports=app