const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/school', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch((error) => {
  console.error('Error connecting to MongoDB', error);
});

// Graceful shutdown: Disconnect MongoDB when the app is stopped
process.on('SIGINT', async () => {
  try {
    await mongoose.disconnect();
    console.log('MongoDB connection closed gracefully');
    process.exit(0);  // Exit the application
  } catch (error) {
    console.error('Error closing MongoDB connection:', error);
    process.exit(1);  // Exit with error code
  }
});
