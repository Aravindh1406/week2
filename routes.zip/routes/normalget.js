const express=require("express")
const route=express();
const student=require("../data/students.json")
route.get("/",(req,res)=>{
    res.status(200)
    res.json(student)
})
module.exports=route