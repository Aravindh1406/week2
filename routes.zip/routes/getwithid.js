const express=require("express")
const route=express();
const student=require("../data/students.json")
route.get("/:id",(req,res)=>{
    const studentId=parseInt(req.params.id,10)
    const filteredStudent=student.find((stu)=>{
        return stu.id===studentId
    })
    if(filteredStudent)
    {
       return res.status(200).json(filteredStudent)
    }
    return res.status(404).json({message:"No student Found with the Provided Id"})
})
module.exports=route